const getDetBuku = async (id) => {
    const response = await fetch(`http://localhost:3000/detail.html/buku/${id}`);
    const result = await response.json();
    return result.data;
};


const loadDetBuku = (book) => {

    const judul = document.getElementById("judul");
    const pengarang = document.getElementById("pengarang");
    const tahun = document.getElementById("tahun");


    const aJudul = document.createElement("a");
    aJudul.textContent = `${book.judul}`;
    judul.appendChild(aJudul);


 
    const aPengarang= document.createElement("a");
    aPengarang = `${book.pengarang}`;
    pengarang.appendChild(aPengarang);
    

    
    const aTahun = document.createElement("a");
    aTahun.textContent = `${book.tahun_terbit}`;
    tahun.appendChild(aTahun);

    


    // judul.innerHTML = `Judul: <p>${book.judul}</p>`;
    // pengarang.innerHTML = `Pengarang: <p>${book.pengarang}</p>`;
    // tahun.innerHTML = `Tahun Terbit: <p>${book.tahun_terbit}</p>`;
};

window.onload = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    if (id) {
        const book = await getDetBuku(id);
        loadDetBuku(book);
    }
};