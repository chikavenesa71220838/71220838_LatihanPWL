const ul = document.getElementById("unlist");
const bukuForm = document.getElementById("bukuForm");

const getBuku = async () => {
    const response = await fetch("http://localhost:3000/buku");
    const result = await response.json();
    //await tuh nungguin respon trus jdiin json lalu di return
    return result.data;
};

const loadBuku = (books) => {
    books.map((book) => {
        const li = document.createElement("li");
        const detailButton = document.createElement("button");
        detailButton.textContent = "Detail"
        detailButton.onclick = async () => {
            window.location.href = `http://localhost:3000/detail.html?id=${book.id}`;
          };

        li.appendChild(document.createTextNode(`${book.judul} oleh ${book.pengarang} (${book.tahun_terbit})`));
        li.appendChild(detailButton);
        ul.appendChild(li);


    });
};


window.onload = async () => {
    const books = await getBuku();
    loadBuku(books);
};