const express = require("express");
const app = express();
const cors = require("cors");
app.use(cors());

const bodyParser = require("body-parser");
app.use(bodyParser.json());

const mysql = require("mysql");
const pool = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "root",
  password: "",
  database: "transaksisdrhn",
});

app.get("/transaksi", (req, res) => {
  const { sortBy, orderBy } = req.query;
  const query = `SELECT * FROM transaksi`;
  pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query(query, (err, rows) => {
      connection.release(); // return the connection to pool
      if (!err) {
        return res.status(200).json({ data: rows });
      } else {
        return res.status(500).json({ error: err });
      }
    });
  });
});

app.post("/transaksi", (req, res) => {
  const { keterangan, nominal, tanggal } = req.body;
  pool.getConnection((err, connection) => {
      if (err) throw err;
      connection.query("SELECT saldo FROM transaksi ORDER BY id DESC LIMIT 1", (err, rows) => { //mengambil data saldo terakhir
          if (err) throw err;
          const currentSaldo = rows[0]?.saldo || 0; //maksud dari rows[0]?.saldo adalah mengambil data saldo terakhir, jika tidak ada data maka akan bernilai 0
          if (keterangan === 'Tarik' && nominal > currentSaldo) { //jika keterangan = tarik dan nominal lebih besar dari saldo terakhir
              return res.status(400).json({ error: "Saldo Anda tidak mencukupi, Anda didiagnosa bokek stadium akhir!" });
          }

          //menghitung saldo sekarang setelah transaksi
            let saldoSkrg;
            if (keterangan === 'Setor') {
              saldoSkrg = currentSaldo + nominal;
            } else {
              saldoSkrg = currentSaldo - nominal;
            }
            
          const query = "INSERT INTO transaksi (keterangan, nominal, tanggal, saldo) VALUES (?, ?, ?, ?)";
          connection.query(query, [keterangan, nominal, tanggal, saldoSkrg], (err, result) => {
              connection.release();
              if (err) throw err;
              res.status(201).json({ id: result.insertId });
          });
      });
  });
});



const { body } = require("express-validator");
app.use(express.json());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
