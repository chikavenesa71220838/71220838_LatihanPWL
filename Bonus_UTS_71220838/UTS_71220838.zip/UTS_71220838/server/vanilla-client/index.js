const thAwal = document.getElementById("transactionRowName");
const tbody = document.getElementById("tableBody");
const nominalInput = document.getElementById("nominal");
const inputTanggal = document.getElementById("tanggal");
const tarikButton = document.getElementById('tarikButton');
const setorButton = document.getElementById('setorButton');
const searchInput = document.getElementById("search");


const getTransaksi = async () =>{
    const response = await fetch("http://localhost:3000/transaksi");
    const result = await response.json();
    return result.data;
};

const renderTransaksi = (transactions) => {
    tbody.innerHTML = ''; // Mengahpus row sebelumnya agar tidak numpuk
    transactions.map((transaction) => {
        const tr = document.createElement('tr');
        const tdKet = document.createElement('td');
        const tdTg= document.createElement('td');
        const tdMut = document.createElement('td');
        const tdSal = document.createElement('td');

        //format tanggal agar bentuknya tidak aneh dan dapat dibaca
        const tgl = new Date(transaction.tanggal);
        tdKet.textContent = transaction.keterangan;
        tdTg.textContent = tgl.toLocaleDateString('id-ID'),{
            day: "2-digit",
            month: "2-digit",
            year: "numeric"
        }

        tdSal.textContent = transaction.saldo;

        if(transaction.keterangan === "Tarik"){
            tdMut.textContent = `-${transaction.nominal}`;
        }else{
            tdMut.textContent = transaction.nominal;
        }

        tr.appendChild(tdKet);
        tr.appendChild(tdTg);
        tr.appendChild(tdMut);
        tr.appendChild(tdSal);

        tbody.appendChild(tr);    

        });
        
    };

    const validasiTransaction = async (keterangan) => { //untuk validasi inputan nominal
        const nominal = parseFloat(nominalInput.value); //parsefloat untuk mengubah string menjadi float
        const tanggal = inputTanggal.value; //untuk ambil value dari input tanggal
        if (isNaN(nominal) || nominal <= 0) { //isnan untuk mengecek apabila nominal not-a-number atau(||) kurang dari sama dengan 0
            alert("Nominal harus berupa angka positif!");
            return; 
        }
        const response = await fetch("http://localhost:3000/transaksi", { 
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ keterangan, nominal, tanggal }),
        });
        if (response.ok) { 
            const transactions = await getTransaksi();
            renderTransaksi(transactions);
        } else {
            const error = await response.json();
            alert(error.error);
        }
    };

    tarikButton.onclick = (event) => {
        event.preventDefault();
        validasiTransaction('Tarik');
    };

    setorButton.onclick = (event) => {
        event.preventDefault();
        validasiTransaction('Setor');
    };

    document.addEventListener("DOMContentLoaded", function() { //untuk menampilkan data yang sudah diinputkan di search
    searchInput.addEventListener("input", function() { 
        const lowerValue = searchInput.value.toLowerCase(); //Mengubah value search menjadi huruf kecil
        const rows = tbody.getElementsByTagName("tr");  //Buat ambil semua baris di tabel

        for (let i = 0; i < rows.length; i++) {     //Looping untuk setiap baris di tabel
            const ket = rows[i].getElementsByTagName("td")[0].textContent.toLowerCase();    //Buat ambil value dari kolom keterangan
            if (ket.includes(lowerValue)) {
                rows[i].style.display = ""; //JIka ada baris yang cocok dengan value di search akan ditampilkan
            } else {
                rows[i].style.display = "none"; //Kalau ga ada di search, barisnya dihilangkan
            }
        }
    });
});

window.onload = async() =>{
    const transactions = await getTransaksi();
    renderTransaksi (transactions);
};
