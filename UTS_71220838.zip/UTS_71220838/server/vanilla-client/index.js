const thAwal = document.getElementById("transactionRowName");
const thead = document.getElementById("thead");
const nominalInput = document.getElementById("nominal");
const inputTanggal = document.getElementById("tanggal");
let currentId = null;

const getTransaksi = async () =>{
    const response = await fetch("http://localhost:3000/transaksi");
    const result = await response.json();
    return result.data;
};

const renderTransaksi = (transactions) => {

    transactions.map((transaction) => {
        const tr = document.createElement('tr');
        const tdKet = document.createElement('td');
        const tdTg= document.createElement('td');
        const tdMut = document.createElement('td');
        const tdSal = document.createElement('td');
        const tarikButton = document.getElementById('tarikButton');
        const setorButton = document.getElementById('setorButton');

        tdKet.textContent = `${transaction.keterangan}`;
        tdMut.textContent = `${transaction.nominal}`;
        tdSal.textContent = `${transaction.saldo}`;
        tdTg.textContent = `${transaction.tanggal}`;

        tr.appendChild(tdKet);
        tr.appendChild(tdTg);
        tr.appendChild(tdMut);
        tr.appendChild(tdSal);

        thead.appendChild(tr);

        tarikButton.onclick = (event) =>{
            event.preventDefault();
            transaction.saldo = transaction.nominal-nominalInput;
            transaction.nominal = `${transaction.nominal}`;
            transaction.tanggal = inputTanggal;
            

            //kenapa ujiannya gampang bgt TvT 😭😭😭😭😭 terima kasih selamat tahun baru semoga panjang pendek dan masukkan sedikit garam
        };

        
    });
};

window.onload = async() =>{
    const transactions = await getTransaksi();
    renderTransaksi (transactions);
};
