const express = require("express");
const app = express();
const { query, validationResult } = require("express-validator");
const cors = require("cors");
app.use(cors());

const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();

const mysql = require("mysql");
const pool = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "root",
  password: "",
  database: "transaksisdrhn",
});

app.get("/transaksi", (req, res) => {
  const { sortBy, orderBy } = req.query;
  const query = `SELECT * FROM transaksi`;
  pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query(query, (err, rows) => {
      connection.release(); // return the connection to pool
      if (!err) {
        return res.status(200).json({ data: rows });
      } else {
        return res.status(500).json({ error: err });
      }
    });
  });
});

app.post("/transaksi", jsonParser, (req, res) => {
  pool.getConnection((err, connection) => {
    if (err) throw err;
    const params = req.body;
    connection.query("INSERT INTO transaksi SET ?", params, (err, rows) => {
      connection.release(); // return the connection to pool
      if (!err) {
        res.status(200).json({ data: rows });
      } else {
        res.status(500).json({ error: err });
      }
    });
  });
});

app.get("/:nominal", (req, res) => {
  pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query(
      "SELECT * FROM transaksi WHERE nominal = ?",
      [req.params.id],
      (err, rows) => {
        connection.release(); // return the connection to pool
        if (!err) {
          res.status(200).json({ data: rows });
        } else {
          res.status(500).json({ error: err });
        }
      }
    );
  });
});

const { body } = require("express-validator");
app.use(express.json());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
