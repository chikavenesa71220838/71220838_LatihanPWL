const express = require("express");
const app = express();
const {query, validationResult} = require('express-validator');
const cors = require('cors');
app.use(cors());


const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();

const mysql = require("mysql");
const pool = mysql.createPool({
  connectionLimit: 10,
  host: "localhost",
  user: "root",
  password: "",
  database: "movies",
});


/*
=============================================================================================
LATIHAN DARI MODUL
=============================================================================================
*/

// app.get('/', (req, res) => {
//     res.send('Hello, World!');
//     });

/*app.get("/", (req, res) => {
    pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query("SELECT * from movies", (err, rows) => {
    connection.release(); // return the connection to pool
    if (!err) {
    res.status(200).json({ data: rows });
    } else {
    res.status(500).json({ error: err });
    }
    });
    });
    });*/

//     app.get("/:id", (req, res) => {
//         pool.getConnection((err, connection) => {
//         if (err) throw err;
//         connection.query(
//         "SELECT * FROM movies WHERE id = ?",
//         [req.params.id],
//         (err, rows) => {
//         connection.release(); // return the connection to pool
//         if (!err) {
//         res.status(200).json({ data: rows });
//         } else {
//         res.status(500).json({ error: err });
//         }
//         }
//     );
// });
// });

app.delete("/:id", (req, res) => {
    pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query(
    "DELETE FROM movies WHERE id = ?",
    [req.params.id],
    (err, rows) => {
        connection.release(); // return the connection to pool
        if (!err) {
        res.status(200).json({ data: rows });
        } else {
        res.status(500).json({ error: err });
        }
        }
    );
        });
        });

app.post("/", jsonParser, (req, res) => {
    pool.getConnection((err, connection) => {
    if (err) throw err;
    const params = req.body;
    connection.query("INSERT INTO movies SET ?", params, (err, rows) => {
    connection.release(); // return the connection to pool
    if (!err) {
    res.status(200).json({ data: rows });
    } else {
    res.status(500).json({ error: err }); }
    });
    });
    });

app.put("/:id", jsonParser, (req, res) => {
    console.log(req);
    const { id } = req.params;
    const params = req.body;
    pool.getConnection((err, connection) => {
    if (err) throw err;
    const fields = [];
    const values = [];
    for (const key in params) {
        fields.push(`${key} = ?`);
        values.push(params[key]);
        }
        const query = `UPDATE movies SET ${fields.join(", ")} WHERE id = ?`;
        values.push(Number(id));
        connection.query(query, values, (err, rows) => {
        connection.release(); // return the connection to pool
        console.log(err);
        if (!err) {
        res.status(200).json({ data: rows });
        } else {
        return res.status(500).json({ error: err });
        }
        });
        });
        });

// app.get("/", (req, res) => {
//     const { sortBy, orderBy } = req.query;
//     console.log(sortBy, orderBy);
//     pool.getConnection((err, connection) => {
//     if (err) throw err;
//     connection.query("SELECT * from movies", (err, rows) => {
//     connection.release(); // return the connection to pool
//     if (!err) {
//     res.status(200).json({ data: rows });
//     } else {
//     res.status(500).json({ error: err });
//     }
//     });
//     });
//     });

app.get("/", (req, res) => {
    const { sortBy, orderBy } = req.query;
    const query = `SELECT * FROM movies ORDER BY ${mysql.escapeId(
    sortBy
    )} ${orderBy.toUpperCase()}`;
    pool.getConnection((err, connection) => {
    if (err) throw err;
    connection.query(query, (err, rows) => {
    connection.release(); // return the connection to pool
    if (!err) {
    return res.status(200).json({ data: rows });
    } else {
    return res.status(500).json({ error: err });
    }
    });
    });
    });

// app.get("/", (req, res) => {
//     const { sortBy, orderBy, title } = req.query;
//     const query = `SELECT * FROM movies WHERE title like ? ORDER BY
//     ${mysql.escapeId(
//     sortBy
//     )} ${orderBy.toUpperCase()}`;
//     pool.getConnection((err, connection) => {
//     if (err) throw err;
//     //dikasih persen biar likenya bisa dipake
//     connection.query(query, [`%${title}%`], (err, rows) => {
//     connection.release(); // return the connection to pool
//     if (!err) {
//     return res.status(200).json({ data: rows });
//     } else {
//     return res.status(500).json({ error: err });
//     }
//     });
//     });
//     });

// app.get("/movies", (req, res) => {
//   const { title } = req.query;
//   let query = "SELECT * FROM movies";
//   if (title) {
//     query += ` WHERE title = '${title}'`;
//   }
//   pool.getConnection((err, connection) => {
//     if (err) {
//       return res.status(500).send(err);
//     }
//     connection.query(query, (err, rows) => {
//       connection.release();
//       if (!err) {
//         return res.status(200).json({ data: rows });
//       } else {
//         return res.status(500).json({ error: err });
//       }
//     });
//   });
// });

// app.get(
//     "/",
//     [
//     query("title").isAlphanumeric(),
//     query("sortBy").optional().trim().escape(),
//     query("orderBy")
//     .optional()
//     .trim()
//     .isIn(["asc", "desc"])
// .withMessage("Invalid sort order"),
// ],
// (req, res) => {
// const { sortBy, orderBy, title } = req.query;
// const errors = validationResult(req);
// if (!errors.isEmpty()) {
// return res.status(400).json({ errors: errors.array() });
// }
// let query = "SELECT * FROM movies";
// if (title) {
// query += ` WHERE title = '${title}'`;
// }
// if (sortBy && orderBy) {
// query += ` ORDER BY ${sortBy} ${orderBy}`;
// }
// pool.getConnection((err, connection) => {
// if (err) throw err;
// connection.query(query, (err, rows) => {
// connection.release();
// if (!err) {
// return res.status(200).json({ data: rows });
// } else {
// return res.status(500).json({ error: err });
// }
// });
// });
// }
// );




/*
=============================================================================================
TUGAS NO 1 
=============================================================================================
*/

const { body } = require('express-validator');
app.use(express.json()); 
app.use(bodyParser.json());

/*
app.post(
  "/movies", jsonParser,
  [
    body('title').notEmpty().withMessage('Title tidak boleh kosong.'),
    body('genre').notEmpty().withMessage('Genre tidak boleh kosong.'),
    

    body('release_year')
      .isInt({ min: 1888, max: new Date().getFullYear() })
      .withMessage('release_year harus berupa tahun yang valid antara 1888 dan tahun sekarang.'),
  ],
  (req, res) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const params = req.body;
    pool.getConnection((err, connection) => {
      if (err) throw err;
      
      connection.query("INSERT INTO movies SET ?", params, (err, rows) => {
        connection.release();
        
        if (!err) {
          res.status(201).json({ data: rows });
        } else {
          res.status(500).json({ error: err.message });
        }
      });
    });
  }
); */


/*
=============================================================================================
TUGAS NO 2
=============================================================================================
*/


// app.put(
//   "/movies/:id", jsonParser,
//   [
//     body('title').notEmpty().withMessage('Title tidak boleh kosong.'),
//     body('genre').notEmpty().withMessage('Genre tidak boleh kosong.'),

//     body('release_year')
//       .isInt({ min: 1888, max: new Date().getFullYear() })
//       .withMessage('Release_year harus berupa tahun yang valid antara 1888 dan tahun sekarang.'),
//   ],
//   (req, res) => {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }

//     const movieId = req.params.id;
//     const updatedData = req.body;

//     pool.getConnection((err, connection) => {
//       if (err) throw err;
      
//       connection.query("SELECT * FROM movies WHERE id = ?", [movieId], (err, rows) => {
//         if (err) {
//           connection.release();
//           return res.status(500).json({ error: err.message });
//         }

//         if (rows.length === 0) {
//           connection.release();
//           return res.status(404).json({ error: `Film dengan id ${movieId} tidak ditemukan.` });
//         }

//         connection.query("UPDATE movies SET ? WHERE id = ?", [updatedData, movieId], (err, result) => {
//           connection.release();
          
//           if (!err) {
//             res.status(200).json({
//               message: `Film dengan id ${movieId} berhasil diupdate.`,
//               data: updatedData
//             });
//           } else {
//             res.status(500).json({ error: err.message });
//           }
//         });
//       });
//     });
//   }
// );



const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
