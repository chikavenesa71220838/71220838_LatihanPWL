const movieId = document.getElementById("movies");
const table = document.getElementById("movieTable");
const movieForm = document.getElementById("movieForm");
const cancelButton = document.getElementById("cancelButton");
const titleInput = document.getElementById("title");
const releaseYearInput = document.getElementById("release_year");
const genreInput = document.getElementById("genre");
const directorInput = document.getElementById("director");
const ratingInput = document.getElementById("rating");
const saveButton = document.querySelector("#movieForm button[type='submit']");
let currentMovieId = null;

const getMovies = async () => {
  const response = await fetch("http://localhost:3000?sortBy=title&orderBy=asc&title=");
  const result = await response.json();
  //await tuh nungguin respon trus jdiin json lalu di return
  return result.data;
};

const renderMovies = (movies) => {
  movies.map((movie) => {
    const row = document.createElement("tr");
    const titleCell = document.createElement("td");
    titleCell.textContent = movie.title;
    row.appendChild(titleCell);
    const releaseYearCell = document.createElement("td");
    releaseYearCell.textContent = movie.release_year;
    row.appendChild(releaseYearCell);
    const genreCell = document.createElement("td");
    genreCell.textContent = movie.genre;
    row.appendChild(genreCell);
    const directorCell = document.createElement("td");
    directorCell.textContent = movie.director;
    row.appendChild(directorCell);
    const ratingCell = document.createElement("td");
    ratingCell.textContent = movie.rating;
    row.appendChild(ratingCell);
    const actionCell = document.createElement("td");
    const editButton = document.createElement("button");
    editButton.textContent = "Edit";
    editButton.onclick = () => {
      // buat fungsi edit disini
      currentMovieId = movie.id;
      titleInput.value = movie.title;
      releaseYearInput.value = movie.release_year;
      genreInput.value = movie.genre;
      directorInput.value = movie.director;
      ratingInput.value = movie.rating;
    };
    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.onclick = async () => {
      // buat fungsi delete disini
      await fetch(`http://localhost:3000/${movie.id}`, {
        method: "DELETE",
      });
      window.location.reload();
    };
    actionCell.appendChild(editButton);
    actionCell.appendChild(deleteButton);
    row.appendChild(actionCell);
    table.appendChild(row);
  });
};
window.onload = async () => {
  const movies = await getMovies();
  renderMovies(movies);
};
movieForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const formData = new FormData(movieForm);
  const movieData = {
    title: formData.get("title"),
    release_year: formData.get("release_year"),
    genre: formData.get("genre"),
    director: formData.get("director"),
    rating: formData.get("rating"),
  };
  let response = await fetch("http://localhost:3000?sortBy=title&orderBy=asc&title=", {
    method: "POST",
    headers: {
      "Content-type": "application/json",
    },
    body: JSON.stringify(movieData),
  });
  if (response) {
    window.location.reload();
    const movies = await getMovies();
    renderMovies(movies);
  }
  movieForm.reset();
});

saveButton.onclick = (event) => {
  event.preventDefault();
  if (currentMovieId) {
    const updatedMovieData = {
      title: titleInput.value,
      release_year: releaseYearInput.value,
      genre: genreInput.value,
      director: directorInput.value,
      rating: ratingInput.value,
    };
    fetch(`http://localhost:3000/${currentMovieId}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updatedMovieData),
    })
      .then((response) => response.json())
      .then(() => {
        window.location.reload();
      });
  }
};

cancelButton.addEventListener("click", () => {
  movieForm.reset();
});
